import React from "react";

const AdminLogin = () => {
  return <div>AdminLogin</div>;
};

export default AdminLogin;
